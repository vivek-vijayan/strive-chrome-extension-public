/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************!*\
  !*** ./src/contentScript.js ***!
  \******************************/
window.addEventListener('load', StriveAppInit, false);

// Websocket activation
function WebSocketTest(ticket, desc) {
  if ('WebSocket' in window) {
    let request = 'ritm=' + ticket + '&desc=' + desc;
    // Let us open a web socket
    var ws = new WebSocket('ws://localhost:59090?' + request);
  } else {
    // The browser doesn't support WebSocket
    alert('WebSocket NOT supported by your Browser!, try using Google Chrome');
  }
}

// injection script --------------------------------------------------------------
function StriveAppInit(evt) {
  console.log('[STRIVE] - Loading Strive Extension in Service Now');
  const topPanel = document.getElementsByClassName('navbar-header');
  let newButton = document.createElement('button');
  newButton.classList.add('activatebutton');
  //newButton.onclick(getTicketNumber());
  const textnode = document.createTextNode('▶  Start Strive Recording');
  let newSpan = document.createElement('span');
  newSpan.appendChild(textnode);
  newButton.appendChild(newSpan);
  newButton.addEventListener('click', function handleClick(event) {
    // If the selected is an SCTASK
    let title = document.getElementById('gsft_main').title;
    if (title.includes('SCTASK')) {
      // SCTASK ---------------------------------------------------------
      let output = [];
      let ritm = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementsByTagName('input');
      output[0] = {
        STRIVE_RITM: ritm[41].value,
      };

      let desc = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementById('sc_task.short_description');
      output[1] = {
        STRIVE_Description: desc.value,
      };
      console.log(output);
      WebSocketTest(ritm[41].value, desc.value);
      // -----------------------------------------------------------------
    } else if (title.includes('RITM')) {
      // RITM -------------------------------------------------------------
      let output = [];
      let ritm = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementsByTagName('input');
      output[0] = {
        STRIVE_RITM: ritm[41].value,
      };

      let desc = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementById('sc_req_item.short_description');
      output[1] = {
        STRIVE_Description: desc.value,
      };
      console.log(output);
      WebSocketTest(ritm[41].value, desc.value);
      // -------------------------------------------------------------------
    } else if (title.includes('INC')) {
      // INCIDENT -------------------------------------------------------------
      let output = [];
      let ritm = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementsByTagName('input');
      output[0] = {
        STRIVE_RITM: ritm[41].value,
      };

      let desc = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementById('incident.short_description');
      output[1] = {
        STRIVE_Description: desc.value,
      };
      console.log(output);
      WebSocketTest(ritm[41].value, desc.value);
      // -------------------------------------------------------------------
    } else if (title.includes('RLSE')) {
      // INCIDENT -------------------------------------------------------------
      let output = [];
      let ritm = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementsByTagName('input');
      output[0] = {
        STRIVE_RITM: ritm[41].value,
      };

      let desc = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementById(
          'sys_readonly.rm_release.short_description'
        );
      output[1] = {
        STRIVE_Description: desc.value,
      };
      console.log(output);
      WebSocketTest(ritm[41].value, desc.value);
      // -------------------------------------------------------------------
    } else if (title.includes('RTSK')) {
      // INCIDENT -------------------------------------------------------------
      let output = [];
      let ritm = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementsByTagName('input');
      output[0] = {
        STRIVE_RITM: ritm[41].value,
      };

      let desc = document
        .getElementById('gsft_main')
        .contentWindow.document.getElementById(
          'sys_readonly.rm_task.short_description'
        );
      output[1] = {
        STRIVE_Description: desc.value,
      };
      console.log(output);
      WebSocketTest(ritm[41].value, desc.value);
      // -------------------------------------------------------------------
    }
  });
  newButton.classList.add('white');
  topPanel[0].appendChild(newButton);
  console.log('[STRIVE] - Appending Strive button to the ServiceNow portal');
}

/******/ })()
;
//# sourceMappingURL=contentScript.js.map